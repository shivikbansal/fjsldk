package com.snowflakeapi.snowflakeapi.ApiConfiguration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@Configuration
@EnableWebMvc
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.snowflakeapi.snowflakeapi.repository")

@ComponentScan(basePackages = "com.snowflakeapi.snowflakeapi")
	
public class ApiConfiguration implements WebMvcConfigurer {
	 @Override
	    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
	        //to see html files
	        configurer.enable();
	    }

	    //Entity manager
	    @Bean(name = "RestApi")
	    public LocalEntityManagerFactoryBean getEntityManagerFactoryBean() {
	        LocalEntityManagerFactoryBean factoryBean = new LocalEntityManagerFactoryBean();
	        factoryBean.setPersistenceUnitName("RestApi");
	        return factoryBean;
	    }
}
