package com.snowflakeapi.snowflakeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnowflakeapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
