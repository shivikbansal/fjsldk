package com.snowflakeapi.snowflakeapi.dialect;

public class EmptyDialect extends org.hibernate.dialect.Dialect {
	
}