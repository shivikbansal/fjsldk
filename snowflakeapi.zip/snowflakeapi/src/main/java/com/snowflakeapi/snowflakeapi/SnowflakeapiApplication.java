package com.snowflakeapi.snowflakeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@SpringBootApplication
@EnableEncryptableProperties
public class SnowflakeapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SnowflakeapiApplication.class, args);
	}
	

}
