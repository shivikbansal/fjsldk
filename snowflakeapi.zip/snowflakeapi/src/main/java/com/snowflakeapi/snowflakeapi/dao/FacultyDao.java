package com.snowflakeapi.snowflakeapi.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.snowflakeapi.snowflakeapi.entities.Faculty;

public interface FacultyDao extends JpaRepository<Faculty,Integer> {
	
//	@Query("select u from Faculty  u ")
//	public List<Faculty> findAll();
	
	@Query("select u from Faculty  u where u.id= :n")
	public List<Faculty> facultyById(@Param("n") int id);

	@Query("select u from Faculty u where u.gender= :n")
	public List<Faculty> facultyByGender(@Param("n") String gender);
	
	@Query("select u.gender from Faculty u where u.id= :n")
	public String getFacultyGender(@Param("n") int id);
}
