package com.snowflakeapi.snowflakeapi.services;

//import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snowflakeapi.snowflakeapi.dao.CourseDao;

import com.snowflakeapi.snowflakeapi.entities.Course;

@Service
public class CourseServiceImpl implements CourseService {
	
	@Autowired
	private CourseDao courseDao;
	

	@Override
	public List<Course> allCourse() {
		
		return (List<Course>) courseDao.allCourse();
	}
	

	@Override
	public List<Course> getCourses() {
//		return list;
		
		return (List<Course>) courseDao.findAll();
	}
	
	@Override
	public List<Course> getCouseById(int id){
		return (List<Course>) courseDao.byID(id);
	}
	

}
