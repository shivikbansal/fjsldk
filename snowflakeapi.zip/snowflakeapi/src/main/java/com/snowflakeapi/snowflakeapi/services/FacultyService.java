package com.snowflakeapi.snowflakeapi.services;

import java.util.List;

import com.snowflakeapi.snowflakeapi.entities.Faculty;

public interface FacultyService {

	public List<Faculty> getFaculty();
	
	public List<Faculty> getFacultyById(int id);

	public List<Faculty> getFacultyByGender(String gender);

	public String getFacultyGender(int id);
	

}
