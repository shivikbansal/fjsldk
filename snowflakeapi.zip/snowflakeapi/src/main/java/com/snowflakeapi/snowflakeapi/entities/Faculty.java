package com.snowflakeapi.snowflakeapi.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Faculty")
public class Faculty {
	@Id
	int id;
	String name;
	String gender;
	String grp_id;
	String grp_name;
	String subscriber_id;
	String age;
	
	public Faculty() {}
	

	public Faculty(int id, String name, String gender, String grp_id, String grp_name, String subscriber_id,
			String age) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.grp_id = grp_id;
		this.grp_name = grp_name;
		this.subscriber_id = subscriber_id;
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "Faculty [id=" + id + ", name=" + name + ", gender=" + gender + ", grp_id=" + grp_id + ", grp_name="
				+ grp_name + ", subscriber_id=" + subscriber_id + ", age=" + age + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getGrp_id() {
		return grp_id;
	}
	public void setGrp_id(String grp_id) {
		this.grp_id = grp_id;
	}
	public String getGrp_name() {
		return grp_name;
	}
	public void setGrp_name(String grp_name) {
		this.grp_name = grp_name;
	}
	public String getSubscriber_id() {
		return subscriber_id;
	}
	public void setSubscriber_id(String subscriber_id) {
		this.subscriber_id = subscriber_id;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
}
