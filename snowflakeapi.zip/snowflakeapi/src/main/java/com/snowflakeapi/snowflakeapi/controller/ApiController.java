package com.snowflakeapi.snowflakeapi.controller;

import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.metadata.*;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.autoconfigure.jdbc.*;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.snowflakeapi.snowflakeapi.entities.Course;
import com.snowflakeapi.snowflakeapi.entities.Faculty;
import com.snowflakeapi.snowflakeapi.services.CourseService;
import com.snowflakeapi.snowflakeapi.services.FacultyService;

@RestController
public class ApiController {
	
	@Autowired
	public CourseService courseService;
	
	@Autowired
	public FacultyService facultyService;
	
	
	@GetMapping("/home")
	public String home() {
		return "welcome home";
	}
	
	@GetMapping("/user/{userName}")
	public String user(@PathVariable("userName") String userName) {
		return ("hloo "+ userName) ;
	}
	
//	@GetMapping("/courseId/{id}")
//	public Course getCourseById(@PathVariable String id) {
////		int a=parseInt(Id);
//		return this.courseService.getCourseById(Integer.parseInt(id));
//	}
	
	//get the courses
	@GetMapping("/courses")
	public List<Course> getCourses(){
		return this.courseService.getCourses();
	}
	@GetMapping("/course")
	public List<Course> allCourse(){
		return this.courseService.allCourse();
	}
	
	@GetMapping("/courseId/{id}")
	public List<Course> CourseId(@PathVariable("id") int id){
		return this.courseService.getCouseById(id);
	}

	//Mapping for faculty
	
	@GetMapping("/faculty")
	public List<Faculty> allFaculty(){
		return this.facultyService.getFaculty();
	}
	
	@GetMapping("/facultyId/{id}")
	public List<Faculty> facultyId(@PathVariable("id") int id){
		return this.facultyService.getFacultyById(id);
	}
	
	@GetMapping("/facultyByGender/{gender}")
	public List<Faculty> facultyByGender(@PathVariable("gender") String gender){
		return this.facultyService.getFacultyByGender(gender);
	}
	
	@GetMapping("/getFacultyGender/{id}")
	public String getFacultyGender(@PathVariable("id") int id) {
		return this.facultyService.getFacultyGender(id);
	}

	
}
