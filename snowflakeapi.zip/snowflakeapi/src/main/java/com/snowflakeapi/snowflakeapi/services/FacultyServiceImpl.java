package com.snowflakeapi.snowflakeapi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snowflakeapi.snowflakeapi.dao.FacultyDao;
import com.snowflakeapi.snowflakeapi.entities.Faculty;

@Service
public class FacultyServiceImpl implements FacultyService  {

	
	@Autowired
	private FacultyDao facultyDao;
	
	@Override
	public List<Faculty> getFaculty() {
		
		return (List<Faculty>)this.facultyDao.findAll();
	}
	
	@Override
	public List<Faculty> getFacultyById(int id) {
		
		return (List<Faculty>)this.facultyDao.facultyById(id);
	}
	
	@Override
	public List<Faculty> getFacultyByGender(String gender){
		return this.facultyDao.facultyByGender(gender);
	}
	
	@Override
	public String getFacultyGender(int id) {
		return this.facultyDao.getFacultyGender(id);
	}

}
