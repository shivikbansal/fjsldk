//package com.snowflakeapi.snowflakeapi.dao;
//
//public class myDao {
//	private static void showAllData() {
//		string 
//	}
//
//}
