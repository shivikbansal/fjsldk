package com.snowflakeapi.snowflakeapi.controller;

import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.metadata.*;
import org.springframework.boot.autoconfigure.jdbc.*;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.snowflakeapi.snowflakeapi.entities.Course;
import com.snowflakeapi.snowflakeapi.services.CourseService;

@RestController
public class ApiController {
	@Autowired
	public CourseService courseService;
	
	@GetMapping("/home")
	public String home() {
		return "welcome home";
	}
	
	@GetMapping("/user/{userName}")
	public String user(@PathVariable String userName) {
		return ("hloo "+ userName) ;
	}
	
	//get the courses
	@GetMapping("/courses")
	public List<Course> getCourses(){
		return this.courseService.getCourses();
	}

}
