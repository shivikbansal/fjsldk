package com.snowflakeapi.snowflakeapi.services;

//import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snowflakeapi.snowflakeapi.dao.CourseDao;

import com.snowflakeapi.snowflakeapi.entities.Course;

@Service
public class CourseServiceImpl implements CourseService {
	
	@Autowired
	private CourseDao courseDao;
	
//	List<Course> list;
	
//	
//	public CourseServiceImpl() {
//		list = new ArrayList<>();
//		list.add(new Course(145, "Java core course", "this is for api"));
//		list.add(new Course(15, " using springboot", " This is for creating api using spring boot"));
//		
//		
//	}

	

	@Override
	public List<Course> getCourses() {
//		return list;
		
		return courseDao.findAll();
	}

}
