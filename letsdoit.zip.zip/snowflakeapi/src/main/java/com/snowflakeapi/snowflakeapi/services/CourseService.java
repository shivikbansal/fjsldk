package com.snowflakeapi.snowflakeapi.services;

import java.util.List;

import com.snowflakeapi.snowflakeapi.entities.Course;

public interface CourseService {
	
	//for loose coupling interface
	public List<Course> getCourses();

}
